package com.pennant.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pennant.models.Employee;
import com.pennant.services.EmpService;

@Controller
public class EmployeeController {

	private final EmpService empService;

	@Autowired
	public EmployeeController(EmpService empService) {
		this.empService = empService;
	}

	@GetMapping(value = "/emplist")
	public String getAllEmployees(Model model) {
		List<Employee> empList = empService.findAll();
		model.addAttribute("elist", empList);
		model.addAttribute("employee", new Employee()); // for the form
		return "emplist";
	}

	@PostMapping(value = "/save")
	public String saveEmployee(@ModelAttribute Employee employee) {
		if (employee.getEmpNo() == null) {
			employee.setEmpNo(0); // Set a default value or handle it as per your application logic
		}
		empService.save(employee);
		return "redirect:/emplist";
	}

	@GetMapping(value = "/edit")
	public String editEmployee(@RequestParam("id") Integer id, Model model) {
		Employee employee = empService.findById(id);
		model.addAttribute("employee", employee);
		List<Employee> empList = empService.findAll();
		model.addAttribute("elist", empList);
		return "emplist";
	}

	@GetMapping(value = "/delete")
	public String deleteEmployee(@RequestParam("id") Integer id) {
		empService.deleteById(id);
		return "redirect:/emplist";
	}
}
