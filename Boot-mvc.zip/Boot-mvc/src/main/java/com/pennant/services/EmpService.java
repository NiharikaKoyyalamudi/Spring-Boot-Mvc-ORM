package com.pennant.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pennant.models.Employee;
import com.pennant.repositories.EmpRepository;

@Service
public class EmpService {

	@Autowired
	private EmpRepository empRepository;

	public List<Employee> findAll() {
		return empRepository.findAll();
	}

	public Employee findById(Integer id) {
		return empRepository.findById(id).orElse(null);
	}

	public Employee save(Employee employee) {
		return empRepository.save(employee);
	}

	public void deleteById(Integer id) {
		empRepository.deleteById(id);
	}
}
