package com.pennant.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pennant.models.Employee;

public interface EmpRepository extends JpaRepository<Employee, Integer> {

}
